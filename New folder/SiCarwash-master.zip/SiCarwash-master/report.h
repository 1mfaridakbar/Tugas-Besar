#ifndef report_h
#define report_h

// DEKLARASI MODUL
void header_laporan_semua(); // MODUL UNTUK EXPORT HEADER LAPORAN TRANSAKSI SEMUA DATA
void tampil_laporan_akumulasi( int jumlah_kendaraan, int jumlah_waktu, int jumlah_harga); // MODUL UNTUK EXPORT LAPORAN AKUMULASI
void hapus_laporan(); // MODUL UNTUK HAPUS LAPORAN
// DEKLARASI MODUL

#endif

