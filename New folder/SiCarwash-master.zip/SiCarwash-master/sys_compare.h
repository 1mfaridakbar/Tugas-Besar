#ifndef sys_compare_h
#define sys_compare_h

// DEKLRASI MODUL
int stringcompare(char*,char*);	//FILE : system_compare.cpp
// DEKLRASI MODUL - END

#endif
