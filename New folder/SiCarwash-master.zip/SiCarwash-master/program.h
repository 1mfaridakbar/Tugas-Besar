#ifndef program_h
#define program_h

// FUNCTION SETIAP HOMEPAGE
int homepage();				//FILE : homepage.cpp

#endif
